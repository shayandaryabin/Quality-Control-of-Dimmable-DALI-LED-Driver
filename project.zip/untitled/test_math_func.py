from math_func import MEAS
from math_func import DUT
import pytest


@pytest.fixture(scope='module')
def db():
    #    print('---------Setup---------')
    db = MEAS()
    #    db = DUT()
    db.connect('data.json')
    yield db
    #    print('---------teardown--------')
    db.close()


def test_one_data(db):
    """compare values(DUT values need to be within +/-5 of MEAS values)"""
    one_data = db.get_data('MEAS')
    voltage_meas = one_data['u_MEAS']
    current_meas = one_data['i_MEAS']

    two_data = db.get_data('DUT')
    voltage_DUT = two_data['u_DUT']
    current_DUT = two_data['i_DUT']

    for j in range(len(voltage_DUT)):
        assert voltage_meas[j] * 1.05 > voltage_DUT[j] > voltage_meas[j] * 0.95
        assert current_meas[j] * 1.05 > current_DUT[j] > current_meas[j] * 0.95





#
